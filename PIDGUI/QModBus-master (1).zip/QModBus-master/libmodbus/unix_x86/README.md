## This version of the library has been compiled in the system:
- Ubuntu 14.04.01  3.13.0-37-generic
- gcc version 4.9.1

**Command for configure and make library:**

```console
$ ./configure --prefix=/home/xxx/projects/libmodbus/libmodbus-3.1.2/lib CFLAGS=-m32 CPPFLAGS=-m32
$ make
$ make install
```

# If you use another system or another compiler, for greater compatibility rebuild the library in your system
